<!DOCTYPE html>
<html lang="en">
<head>
	<title>Update College</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>


	<div class="container-contact100" style="background-image: url('images/pic2.jpg');">
		<div class="wrap-contact100">
			<form class="contact100-form validate-form" action = "Update.php" method = "post">
				<span class="contact100-form-title">
					College Update Form
				</span>
				
				<div class="wrap-input100 validate-input" data-validate="College entry ID is required">
					<span class="label-input100">College Entry ID</span>
					<input class="input100" type="text" name="entry_id" placeholder="Enter college entry ID">
					<span class="focus-input100"></span>
				</div>

				<div class="wrap-input100 validate-input" data-validate="College name is required">
					<span class="label-input100">College Name</span>
					<input class="input100" type="text" name="name" placeholder="Enter college name">
					<span class="focus-input100"></span>
				</div>

				<div class="wrap-input100 validate-input" data-validate = "College course is required">
					<span class="label-input100">College Course</span>
					<input class="input100" type="text" name="course" placeholder="Enter college course">
					<span class="focus-input100"></span>
				</div>

				<div class="wrap-input100 validate-input" data-validate = "College location is required">
					<span class="label-input100">College Location</span>
					<input class="input100" type="text" name="location" placeholder="Enter college location">
					<span class="focus-input100"></span>
				</div>
				
				<div class="wrap-input100 validate-input" data-validate = "College facility is required">
					<span class="label-input100">College Facility</span>
					<input class="input100" type="text" name="facility" placeholder="Enter college facility">
					<span class="focus-input100"></span>
				</div>
				
				<div class="wrap-input100 validate-input" data-validate = "College collaboration partner is required">
					<span class="label-input100">College Collaboration Partner</span>
					<input class="input100" type="text" name="collab" placeholder="Enter college collaboration partner">
					<span class="focus-input100"></span>
				</div>
				
				<div class="wrap-input100 validate-input" data-validate = "College campus is required">
					<span class="label-input100">College Campus</span>
					<input class="input100" type="text" name="campus" placeholder="Enter college campus">
					<span class="focus-input100"></span>
				</div>
				
				<div class="wrap-input100 validate-input" data-validate = "About us is required">
					<span class="label-input100">College About Us</span>
					<textarea class="input100" name="aboutus" placeholder="Your about us here..."></textarea>
					<span class="focus-input100"></span>
				</div>

				<div class="container-contact100-form-btn">
					<div class="wrap-contact100-form-btn">
						<div class="contact100-form-bgbtn"></div>
						<button class="contact100-form-btn">
							<span>
								Update College
								<i class="fa fa-long-arrow-right m-l-7" aria-hidden="true" name = "submit"></i>
								<input type = "hidden" name = "submitted" value = "true"/>
							</span>
						</button>
					</div>
				</div>
			</form>
		</div>
	</div>

	<?php
	
	if(isset($_POST['submitted'])){
	$dbc = mysqli_connect('localhost', 'root', '');
    mysqli_select_db($dbc, 'collegeInfo');
	$problem = FALSE;
	if((!empty($_POST['name'])) && (!empty($_POST['course'])) && (!empty($_POST['aboutus'])) && (!empty($_POST['location'])) 
		&& (!empty($_POST['facility'])) && (!empty($_POST['entry_id'])) && (!empty($_POST['collab'])) && (!empty($_POST['campus']))){
			$entry_id = trim($_POST['entry_id']);
			$name = trim($_POST['name']);
			$course = trim($_POST['course']);
			$aboutus = trim($_POST['aboutus']);
			$location = trim($_POST['location']);
			$facility = trim($_POST['facility']);
			$collab = trim($_POST['collab']);
			$campus = trim($_POST['campus']);
			
		}
		else{
			print '<p style = "color:red;">No data entered.</p>';
			$problem = TRUE;
		}
		if(!$problem){
			
				$sql = "UPDATE information SET name = '$name', course = '$course', about_us = '$aboutus', location = '$location', facilities = '$facility', collab = '$collab', campus = '$campus' WHERE entry_id = '$entry_id'";  
	
			if ($result = mysqli_query($dbc, $sql)){ 
				echo "Records updated successfully.";
			}
			else{ 
				echo "ERROR: Could not able to execute $sql. "; 
				}
			
		}	
	mysqli_close($dbc);
	
	}
	
?>


	<div id="dropDownSelect1"></div>

<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
	<script>
		$(".selection-2").select2({
			minimumResultsForSearch: 20,
			dropdownParent: $('#dropDownSelect1')
		});
	</script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

	<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>

</body>
</html>
