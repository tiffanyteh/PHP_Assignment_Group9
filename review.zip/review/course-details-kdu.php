<!doctype html>
<html lang="en">

<head>
<title>KDU Penang University College, Georgetown Campus</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="img/favicon.png" type="image/png">
    <title>College Details</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="vendors/linericon/style.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
    <link rel="stylesheet" href="vendors/lightbox/simpleLightbox.css">
    <link rel="stylesheet" href="vendors/nice-select/css/nice-select.css">
    <link rel="stylesheet" href="vendors/animate-css/animate.css">
    <!-- main css -->
    <link rel="stylesheet" href="css/style.css">
	<!--this line of code will keep website responsive after adding this meta tag just come back to the body section-->
<meta name="viewport" content="with=device-width, initial-scale=1.0">

</head>

<body>
<p id="time"></p>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script type="text/javascript">
    var timestamp = '<?=time();?>';
    function updateTime(){
    $('#time').html(Date(timestamp));
    timestamp++;
    }
    $(function(){
    setInterval(updateTime, 1000);
    });
    </script>
<style>
.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  text-align: left;
  background-image: linear-gradient(to right, #a9a9a9, #ffffff);
}

.menu-bar
{
	background-image: linear-gradient(to right, #808080, #a9a9a9);
	
}

.nav-link
{
	font-size: 20px;
	margin: 3px;
	
}

.menu-bar .navbar-toggler
{
	padding-right: 0;
	outline: none;
	border: none;
	
}
</style>

<!-- header-->
<section id="header">
<div class="menu-bar">
<nav class="navbar navbar-expand-lg navbar-light">
  <a class="navbar-brand" href="http://localhost:8080/register/search/home-page.php"><img src="img/college.png" width="80" height="80"></a>
     
<button class="navbar-toggler" type="type" data-toggle="collapse" data-target="#navbarNav" 
aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
   <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item ">
        <a class="nav-link" href="http://localhost:8080/register/search/home-page.php">Home </a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="review-college.html">Review</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="http://localhost:8080/register/search/Login_v16/index.php">Admin</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="http://localhost:8080/register/search/compare/Table_Highlight_Vertical_Horizontal/compare.php">Compare</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="http://localhost:8080/register/regiser.php">Register/Login</a>
      </li>
    </ul>
  </div>
</nav>
</div>
</section>

    <!--================ Start Course Details Area =================-->
    <section class="course_details_area section_gap">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 course_details_left">
                    <div class="main_image">
                        <img class="img-fluid" src="img/kdu2.jpg" alt="">
                    </div>
                    <div class="content_wrapper">
                        <h4 class="title">Objectives</h4>
							<?php
								$connection = mysqli_connect('localhost', 'root','', 'collegeinfo'); // Establishing Connection with Server
								$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
								$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=4');
								while ($row1 = mysqli_fetch_array($query1)) {
							?>
								<?php echo $row1['name']; ?>
								<?php
								}
								?>
                        <div class="content">
							<?php
								$connection = mysqli_connect('localhost', 'root','', 'collegeinfo'); // Establishing Connection with Server
								$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
								$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=4');
								while ($row1 = mysqli_fetch_array($query1)) {
							?>
								<?php echo $row1['about_us']; ?>
								<?php
								}
								?>
						</div>
						
						<style>

						h3 {margin-left: 0px;}

						textarea {
						  margin-top: 10px;
						  margin-left: 0px;
						  width: 500px;
						  height: 100px;
						  -moz-border-bottom-colors: none;
						  -moz-border-left-colors: none;
						  -moz-border-right-colors: none;
						  -moz-border-top-colors: none;
						  background: none repeat scroll 0 0 rgba(0, 0, 0, 0.07);
						  border-color: -moz-use-text-color #FFFFFF #FFFFFF -moz-use-text-color;
						  border-image: none;
						  border-radius: 6px 6px 6px 6px;
						  border-style: none solid solid none;
						  border-width: medium 1px 1px medium;
						  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12) inset;
						  color: #555555;
						  font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
						  font-size: 1em;
						  line-height: 1.4em;
						  padding: 5px 8px;
						  transition: background-color 0.2s ease 0s;
						}


						textarea:focus {
							background: none repeat scroll 0 0 #FFFFFF;
							outline-width: 0;
						}
						</style>
						<br>
						<h3>Review</h3>
						<form action = "course-details-kdu.php" method = "post"/>
						<textarea placeholder="Enter the college review" rows="20" name="review" id="comment_text" cols="40" class="ui-autocomplete-input" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true"></textarea>
						<br>
						<input type = "submit" name = "submit" class="primary-btn text-uppercase enroll" value = "submit" style=margin-left:0px;/>
						<input type = "hidden" name = "submitted" value = "true"/>
						</form>

						<?php
							
							if(isset($_POST['submitted'])){
							$dbc = mysqli_connect('localhost', 'root', '');
							mysqli_select_db($dbc, 'collegeinfo');
							$problem = FALSE;
							if((!empty($_POST['review']))){
									$review = trim($_POST['review']);
									
								}
								else{
									print '<p style = "color:red;">No data entered.</p>';
									$problem = TRUE;
								}
								if(!$problem){
									
										$sql = "UPDATE information SET review = '$review' WHERE entry_id = 4";  
							
									if ($result = mysqli_query($dbc, $sql)){ 
										echo "Review Submitted Successfully.";
									}
									else{ 
										echo "ERROR: Could not able to execute $sql. "; 
										}
									
								}	
							mysqli_close($dbc);
							
							}
							
						?>
						
                    </div>
                </div>


                <div class="col-lg-4 right-contents">
                      <ul>
                        <li>
                            <a class="justify-content-between d-flex" href="#">
                                <p>Courses:&nbsp;&nbsp;</p>
                                <span class="or">
									<?php
									$connection = mysqli_connect('localhost', 'root','', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=4');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['course']; ?>
									<?php
									}
									?>
								</span>
                            </a>
                        </li>
                        <li>
                            <a class="justify-content-between d-flex" href="#">
                                <p>Facilities:&nbsp;&nbsp;</p>
                                <span>
									<?php
									$connection = mysqli_connect('localhost', 'root','', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=4');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['facilities']; ?>
									<?php
									}
									?>
								</span>
                            </a>
                        </li>
                        <li>
                            <a class="justify-content-between d-flex" href="#">
                                <p>Location:&nbsp;&nbsp;</p>
                                <span>
									<?php
									$connection = mysqli_connect('localhost', 'root','', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=4');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['location']; ?>
									<?php
									}
									?>
								</span>
                            </a>
                        </li>
                        <li>
                            <a class="justify-content-between d-flex" href="#">
                                <p>Campus:&nbsp;&nbsp;</p>
                                <span>
									<?php
									$connection = mysqli_connect('localhost', 'root','', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=4');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['campus']; ?>
									<?php
									}
									?>
								</span>
                            </a>
                        </li>
						<li>
                            <a class="justify-content-between d-flex" href="#">
                                <p>Collaboration&nbsp;&nbsp; & Partners:&nbsp;&nbsp;</p>
                                <span>
									<?php
									$connection = mysqli_connect('localhost', 'root','', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=4');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['collab']; ?>
									<?php
									}
									?>
								</span>
                            </a>
                        </li>
                    </ul>
                    <a href="http://localhost:8080/register/search/compare/Table_Highlight_Vertical_Horizontal/compare.php" class="primary-btn text-uppercase enroll">Compare</a>

                    
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--================ End Course Details Area =================-->

<!--================ Footer =================-->
<div class="footer">
		<div class="container">
			<div class="row row-pb-md">
				<div class="col-md-4 fh5co-widget">
					<img src="img/college.png" width="50" height="50">College Portal
					
				</div>
				
					<ul class="fh5co-footer-links">
						<li><a href="http://localhost:8080/register/search/contact-college.php">Contact</a></li>
					</ul>
					
			<div class="row copyright">
				<div class="col-md-12 text-right">
					<p>
						<small class="block">&copy; Group 9</small> 					
					</p>
				</div>
			</div>
		  </div>
		</div>
</div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/stellar.js"></script>
    <script src="vendors/nice-select/js/jquery.nice-select.min.js"></script>
    <script src="vendors/owl-carousel/owl.carousel.min.js"></script>
    <script src="js/owl-carousel-thumb.min.js"></script>
    <script src="js/jquery.ajaxchimp.min.js"></script>
    <script src="vendors/counter-up/jquery.counterup.js"></script>
    <script src="js/mail-script.js"></script>
    <!--gmaps Js-->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCjCGmQ0Uq4exrzdcL6rvxywDDOvfAu6eE"></script>
    <script src="js/gmaps.min.js"></script>
    <script src="js/theme.js"></script>
</body>

</html>