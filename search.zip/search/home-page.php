<!DOCTYPE html>
<html lang="en">
<head>
	<title>Home Page</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/linearicons-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/slick/slick.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<style>
.footer {
  left: 0;
  bottom: 0;
  width: 100%;
  text-align: left;
  background-image: linear-gradient(to right, #a9a9a9, #ffffff);
}

.menu-bar
{
	background-image: linear-gradient(to right, #808080, #a9a9a9);
	width: 100%;
	height: 5%;
}

.nav-link
{
	font-size: 16px;
	margin: 3px;
		
}

.menu-bar .navbar-toggler
{
	padding-right: 0;
	outline: none;
	border: none;
}

</style>


<body class="animsition">
<p id="time"></p>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script type="text/javascript">
    var timestamp = '<?=time();?>';
    function updateTime(){
    $('#time').html(Date(timestamp));
    timestamp++;
    }
    $(function(){
    setInterval(updateTime, 1000);
    });
</script>

<!-- header-->
<section id="header">
<div class="menu-bar">
<nav class="navbar navbar-expand-lg navbar-light" >
  <a class="navbar-brand" href="home-page.php"><img src="image/college.png" width="80" height="80"></a>
 
	<button class="navbar-toggler" type="type" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" 
   aria-label="Toggle navigation">
   <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarNav" > 
    <ul class="navbar-nav">
      <li class="nav-item ">
        <a class="nav-link" href="home-page.php"><b>Home </b></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="review/review-college.html"><b>Review</b></a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="Login_v16/index.php"><b>Admin</b></a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="compare/Table_Highlight_Vertical_Horizontal/compare.php"><b>Compare</b></a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="http://localhost:8080/register/regiser.php"><b>Register/Login</b></a>
      </li>
    </ul>
	
  </div>
</nav>
</div>
</section>

	<!-- Slider -->
	<section class="section-slide">
		<div class="wrap-slick1 rs1-slick1">
			<div class="slick1">
				<div class="item-slick1" style="opacity:0.4;filter:alpha(opacity=40); background-image: url(image/home-main.jpg);" >
					<div class="container h-full">
						<div class="flex-col-l-m h-full p-t-80 p-b-400">
							<div class="layer-slick1 animated visible-false" data-appear="fadeInDown" data-delay="0">
								<span class="ltext-101 respon2" style="color:#e0dede" >
									Welcome to our College Portal
								</span>
							</div>
								
							<div class="layer-slick1 animated visible-false" data-appear="fadeInUp" data-delay="800">
								<h2 class="ltext-104 p-t-20 p-b-30 respon1" style="color: #dedede ">
									Find the perfect college
								</h2>
							</div>
								
							<div class="layer-slick1 animated visible-false" data-appear="zoomIn" data-delay="1600">
								<form method="post" action="search-college.php" >
									<div class="input-group input-group-lg w-100 flakh px-3 px-md-0" role="search">
										<label for="search" class="sr-only">Enter a keyword</label>
										<input type="text" name="search" class="form-control keyword px-4 border-0 rounded-left" placeholder="College or keyword..." autocomplete="off" aria-labelby="Enter school or keyword..." required>
										<div class="invalid-feedback position-absolute m-0">
											Please enter a keyword
										</div>

										<div class="input-group-append p-1 p-md-2 bg-white rounded-right">
											<button class="flex-c-m stext-101 size-101 rounded-right rounded-left bor1 hov-btn3 p-lr-10 trans-04 pointer" type = "submit" name = "submit" style="background-color:#808080">
												Search
											</button>
										</div>
									</div>
								</form>

							</div>
							<div class="input-wrap">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<!-- Content page -->
	<section class="bg0 p-t-75 p-b-100"  style="background-color:#dedede;">
		<div class="p-b-50 h-full" >
				<h3 class="mtext-111 cl2 p-b-16" style="font-size:40px; font color:#000000;text-align:center;">
						<u><b>About Us</b></u>
				</h3>
		</div>
		<div class="container"  style="background-color:#dbdbdb;">
			<div class="row p-b-100" >
				<div class="col-md-7 col-lg-8">
					<div class="p-t-7 p-r-85 p-r-15-lg p-r-0-md">
						<h3 class="mtext-111 cl2 p-b-16">
							Our Story
						</h3>

						<p class="stext-113 cl6 p-b-26" style="font-size:16px;">
							It is created in year 2018. The most robust source of college and university information available for anywhere and anytime. We are focused on providing one stop solutions for users with a wide range of credible colleges.
 
						</p>

						<p class="stext-113 cl6 p-b-26" style="font-size:16px;">
							A comprehensive online college search guide portal helps students to discover their best fit educational program. For examples: Two-year or Four-year, Undergraduate or Graduate, Certificate program or online degree. 
						</p>

					</div>
				</div>
				<div class="col-11 col-md-5 col-lg-4 m-lr-auto">
					<div class="how-bor1 ">
						<div class="hov-img0">
							<img src="image/about_img1.jpg" alt="IMG">
						</div>
					</div>
				</div>
			</div>
			<br><br>
			<div class="row">
				<div class="order-md-2 col-md-7 col-lg-8 p-b-30">
					<div class="p-t-7 p-l-85 p-l-15-lg p-l-0-md">
						<h3 class="mtext-111 cl2 p-b-16">
							Our Mission
						</h3>

						<p class="stext-113 cl6 p-b-26" style="font-size:16px;">
							A website with information about universities and colleges in Malaysia and abroad for those who like the do-it-yourself approach. You can search, compare and apply to universities and colleges on this site. 100% free of charge.
						</p>

						<div class="bor16 p-l-29 p-b-9 m-t-22">
							<p class="stext-114 cl6 p-r-40 p-b-11" style="font-size:15px;">
								Creativity is just connecting things. When you ask creative people how they did something, they feel a little guilty because they didn't really do it, they just saw something. It seemed obvious to them after a while.
							</p>

							<span class="stext-111 cl8" style="font-size:15px;">
								- Steve Job’s 
							</span>
						</div>
					</div>
				</div>

				<div class="order-md-1 col-11 col-md-5 col-lg-4 m-lr-auto p-b-30">
					<div class="how-bor2">
						<div class="hov-img0">
							<img src="image/about_img2.jpg" alt="IMG">
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>	
	
	<!-- Banner -->
	<div class="p-b-40 p-t-45"  style="background-color:#f5f5f5;">
		<h3 class="ltext-105 cl5 txt-center respon1" style="font-size:40px">
			<u>Articles/News </u>
		</h3>
	</div>	
				
	<div class="sec-banner bg0"  style="background-color:#dbdbdb;">
		<div class="flex-w flex-c-m">
			<div class="size-202 m-lr-auto respon4">
			
				<!-- Block1 -->
				<div class="block1 wrap-pic-w">
					<img src="image/banner_1.jpg" alt="IMG-BANNER">

					<a href="https://www.nytimes.com/2018/05/19/opinion/advice-for-college-students.html" class="block1-txt ab-t-l s-full flex-col-l-sb p-lr-38 p-tb-34 trans-03 respon3">
						<div class="block1-txt-child1 flex-col-l">
							<span class="block1-name ltext-102 trans-04 p-b-8">
								Advice for Students
							</span>

							<span class="block1-info stext-102 trans-04">
								How can young people navigate the college years?
							</span>
						</div>

						<div class="block1-txt-child2 p-b-4 trans-05">
							<div class="block1-link stext-101 cl0 trans-09">
								Read Now
							</div>
						</div>
					</a>
				</div>
			</div>

			<div class="size-202 m-lr-auto respon4">
				<!-- Block1 -->
				<div class="block1 wrap-pic-w">
					<img src="image/banner_2.jpg" alt="IMG-BANNER">

					<a href="https://www.thestar.com.my/opinion/letters/2019/06/13/harsh-reality-of-education-in-malaysia/" class="block1-txt ab-t-l s-full flex-col-l-sb p-lr-38 p-tb-34 trans-03 respon3">
						<div class="block1-txt-child1 flex-col-l">
							<span class="block1-name ltext-102 trans-04 p-b-8">
								Education NEWS
							</span>

							<span class="block1-info stext-102 trans-04">
								harsh reality of education							
							</span>
						</div>

						<div class="block1-txt-child2 p-b-4 trans-05">
							<div class="block1-link stext-101 cl0 trans-09">
								Shop Now
							</div>
						</div>
					</a>
				</div>
			</div>

			<div class="size-202 m-lr-auto respon4">
				<!-- Block1 -->
				<div class="block1 wrap-pic-w">
					<img src="image/banner_3.jpg" alt="IMG-BANNER">
					<a href="https://www.businessinsider.com/the-best-advice-college-students-never-hear-2014-7?IR=T" class="block1-txt ab-t-l s-full flex-col-l-sb p-lr-38 p-tb-34 trans-03 respon3">
						<div class="block1-txt-child1 flex-col-l">
							<span class="block1-name ltext-102 trans-04 p-b-8" >
								The Best Advice 
							</span>

							<span class="block1-info stext-102 trans-04">
								for college student never hear
							</span>
						</div>

						<div class="block1-txt-child2 p-b-4 trans-05">
							<div class="block1-link stext-101 cl0 trans-09">
								Read More
							</div>
						</div>
					</a>
				</div>
			</div>
		</div>
	</div>


	<!-- Best top 5 college -->
	<section class="sec-product bg0 p-t-100 p-b-50" style="background-color:#dedede;">
		<div class="container">
			<div class="p-b-32">
				<h3 class="ltext-105 cl5 txt-center respon1" style="font-size:40px">
					College Overview
				</h3>
			</div>

			<!-- Tab01 -->
			<div class="tab01">
				<!-- Nav tabs -->
				<ul class="nav nav-tabs" role="tablist">
					<li class="nav-item p-b-10">
						<a class="nav-link active" data-toggle="tab" href="" role="tab" style="background-color:#dedede;">Best TOP 5</a>
					</li>

				</ul>

				<!-- Tab panes -->
				<div class="tab-content p-t-50">
					<div class="tab-pane fade show active" id="best-seller" role="tabpanel">
						<!-- Slide2 -->
						<div class="wrap-slick2">
							<div class="slick2">
								<div class="item-slick2 p-l-15 p-r-15 p-t-15 p-b-15">
									<!-- Block2 -->
									<div class="block2">
										<div class="block2-pic hov-img0">
											<img src="image/inti_home.jpg" alt="IMG-PRODUCT" height="290" width="850">
											<a href="http://localhost:8080/register/search/review/course-details-inti.php" class="block2-btn flex-c-m stext-103 cl2 size-102 bg0 bor2 hov-btn1 p-lr-15 trans-04 js-show-modal1" >
												Quick View
											</a>
										</div>

										<div class="block2-txt flex-w flex-t p-t-14">
											<div class="block2-txt-child1 flex-col-l ">
												<a href="http://localhost:8080/register/search/review/course-details-inti.php" class="stext-105 cl4 hov-cl1 trans-04 js-name-b2 p-b-6" style="font-size:16px">
													INTI University College 
												</a>

												<span class="stext-104 cl3">
													Penang | Selangor | Sabah <br>Malaysia
												</span>
											</div>
										</div>
									</div>
								</div>

								<div class="item-slick2 p-l-15 p-r-15 p-t-15 p-b-15">
									<!-- Block2 -->
									<div class="block2">
										<div class="block2-pic hov-img0">
											<img src="image/kdu_home.jpg" alt="IMG-PRODUCT" height="290" width="850">

											<a href="http://localhost:8080/register/search/review/course-details-kdu.php" class="block2-btn flex-c-m stext-103 cl2 size-102 bg0 bor2 hov-btn1 p-lr-15 trans-04 js-show-modal1">
												Quick View
											</a>
										</div>

										<div class="block2-txt flex-w flex-t p-t-14">
											<div class="block2-txt-child1 flex-col-l ">
												<a href="http://localhost:8080/register/search/review/course-details-kdu.php" class="stext-104 cl4 hov-cl1 trans-04 js-name-b2 p-b-6" style="font-size:16px">
													KDU University College
												</a>

												<span class="stext-105 cl3">
													Penang | Selangor <br>Malaysia
												</span>
											</div>
										</div>
									</div>
								</div>

								<div class="item-slick2 p-l-15 p-r-15 p-t-15 p-b-15">
									<!-- Block2 -->
									<div class="block2">
										<div class="block2-pic hov-img0">
											<img src="image/usm_home.jpg" alt="IMG-PRODUCT" height="290" width="850">

											<a href="http://localhost:8080/register/search/review/course-details-usm.php" class="block2-btn flex-c-m stext-103 cl2 size-102 bg0 bor2 hov-btn1 p-lr-15 trans-04 js-show-modal1">
												Quick View
											</a>
										</div>

										<div class="block2-txt flex-w flex-t p-t-14">
											<div class="block2-txt-child1 flex-col-l ">
												<a href="http://localhost:8080/register/search/review/course-details-usm.php" class="stext-104 cl4 hov-cl1 trans-04 js-name-b2 p-b-6" style="font-size:16px">
													USM College
												</a>

												<span class="stext-105 cl3">
													Penang Malaysia
												</span>
											</div>
										</div>
									</div>
								</div>

								<div class="item-slick2 p-l-15 p-r-15 p-t-15 p-b-15">
									<!-- Block2 -->
									<div class="block2">
										<div class="block2-pic hov-img0">
											<img src="image/segi_home.jpg" alt="IMG-PRODUCT" height="290" width="850">

											<a href="http://localhost:8080/register/search/review/course-details-segi.php" class="block2-btn flex-c-m stext-103 cl2 size-102 bg0 bor2 hov-btn1 p-lr-15 trans-04 js-show-modal1">
												Quick View
											</a>
										</div>

										<div class="block2-txt flex-w flex-t p-t-14">
											<div class="block2-txt-child1 flex-col-l ">
												<a href="http://localhost:8080/register/search/review/course-details-segi.php" class="stext-104 cl4 hov-cl1 trans-04 js-name-b2 p-b-6" style="font-size:16px">
													Segi College
												</a>

												<span class="stext-105 cl3">
													Penang Malaysia
												</span>
											</div>
										</div>
									</div>
								</div>
								
								<div class="item-slick2 p-l-15 p-r-15 p-t-15 p-b-15">
									<!-- Block2 -->
									<div class="block2">
										<div class="block2-pic hov-img0">
											<img src="image/taylor_home.jpg" alt="IMG-PRODUCT" height="290" width="850">

											<a href="http://localhost:8080/register/search/review/course-details-taylors.php" class="block2-btn flex-c-m stext-103 cl2 size-102 bg0 bor2 hov-btn1 p-lr-15 trans-04 js-show-modal1">
												Quick View
											</a>
										</div>

										<div class="block2-txt flex-w flex-t p-t-14">
											<div class="block2-txt-child1 flex-col-l ">
												<a href="http://localhost:8080/register/search/review/course-details-taylors.php" class="stext-104 cl4 hov-cl1 trans-04 js-name-b2 p-b-6" style="font-size:16px">
													Taylor University
												</a>

												<span class="stext-105 cl3">
													Selangor | Penang <br> Malaysia
												</span>
											</div>
										</div>
									</div>
								</div>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	
	<div class="footer">
		<div class="container">
			<div class="row row-pb-md">
				<div class="col-md-4 fh5co-widget">
					<img src="image/college.png" width="50" height="50">College Portal
					
				</div>
				
					<ul class="fh5co-footer-links">
						<li><a href="contact-college.php">Contact</a></li> 
					</ul>
				

			<div class="row copyright">
				<div class="col-md-12 text-right">
					<p>
						<small class="block">&copy; Group9.</small> 
						
					</p>
					
				</div>
			</div>
		  </div>
		</div>
	</div>

	<!-- Back to top -->
	<div class="btn-back-to-top" id="myBtn">
		<span class="symbol-btn-back-to-top">
			<i class="zmdi zmdi-chevron-up"></i>
		</span>
	</div>


<!--===================================TEMPLATE============================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/slick/slick.min.js"></script>
	<script src="js/slick-custom.js"></script>
<!--===============================================================================================-->
	<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
	<script>
		$('.js-pscroll').each(function(){
			$(this).css('position','relative');
			$(this).css('overflow','hidden');
			var ps = new PerfectScrollbar(this, {
				wheelSpeed: 1,
				scrollingThreshold: 1000,
				wheelPropagation: false,
			});

			$(window).on('resize', function(){
				ps.update();
			})
		});
	</script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>