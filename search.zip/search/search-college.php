<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 50%;
  border=0;
  align = center;
}

td, th {
  border: 1px solid #dddddd;
  text-align: center;
  padding: 8px;
  background-color: #ffffff;
  background: rgba(255,255,255,0.6);
}

</style>
<head>
<title>Search</title>
</head>
<body style="filter:alpha(opacity=40); background-image: url(image/search-home.jpg); background-size: cover;">
<div class = "container" align="center" style = "padding: 40px 100px;">
	<a class="logo" href="home-page.php"><img src="image/college.png" width="100" height="90"></a>
	<form action = "" method = "post">
		<input type = "text" name = "search"  placeholder="College or keyword..." style="padding: 10px 50px;" autocomplete="off"/>
		<button style="border-radius: 2px; padding: 10px 28px;" name = "submit">search</button>
	</form>
</div>



<?php
	$found = false;
	$dbc = mysqli_connect('localhost','root','','collegeinfo');
	$set = null;
	$search = null;
	$set = $_POST['search'];
	
	echo '<table align = "center">';
	echo "<tr>";
	echo '<th style="text-align:left;"><b>Search Results :  '. $set .'</b><br></th>';
	echo "</tr>";
		if(isset($set) && (!empty($set))){
			$show = "SELECT * FROM information where CONCAT (`name`,`location`,`course`) LIKE '%$set%'";
			$result = mysqli_query($dbc,$show);
			
			while($rows=mysqli_fetch_array($result)){
				echo "<tr>";
				echo '<td><a href="'.$rows['link'].'">'.$rows['name'].'</a></td>';
				echo "</tr>\n";
				$found = true;
			}
			
			if((!$found)){
				echo "<tr>";
				echo '<td>NO COLLEGE FOUND!</td>';
				echo "</tr>\n";
			}
		}
	
	else{
		echo "<tr style='text-align:center'>";
		echo "<script>alert('Please enter college name to search!')</script>";
		echo "</tr>\n";
	}
	
	mysqli_close($dbc);
?>

</body>	


