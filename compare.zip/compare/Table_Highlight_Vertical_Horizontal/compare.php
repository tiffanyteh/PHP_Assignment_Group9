<!DOCTYPE html>
<html lang="en">
<head>
<title>Compare</title>

	
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/perfect-scrollbar/perfect-scrollbar.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	<div class="limiter">
		<div class="container-table100">
			<div class="wrap-table100">
				<div class="table100 ver1 m-b-110">
				<h2 style=text-align:center><b>Comparison between 5 Colleges</b></h2><br>
					<table data-vertable="ver1">
						<thead>
							<tr class="row100 head">
								<th class="column100 column1" data-column="column1"></th>
								<th class="column100 column2" data-column="column2">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=1');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['name']; ?>
									<?php
									}
									
								?>
								</th>
								<th class="column100 column3" data-column="column3">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=2');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['name']; ?>
									<?php
									}
									
								?>
								</th>
								<th class="column100 column4" data-column="column4">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=3');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['name']; ?>
									<?php
									}
									
								?>
								</th>
								<th class="column100 column5" data-column="column5">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=4');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['name']; ?>
									<?php
									}
									
								?>
								</th>
								<th class="column100 column6" data-column="column6">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=5');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['name']; ?>
									<?php
									}
									
								?>
								</th>
							</tr>
						</thead>
						<tbody>
							<tr class="row100">
								<td class="column100 column1" data-column="column1">Location</td>
								<td class="column100 column2" data-column="column2">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=1');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['location']; ?>
									<?php
									}
									
								?>
								</td>
								<td class="column100 column3" data-column="column3">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=2');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['location']; ?>
									<?php
									}
									
								?>
								</td>
								<td class="column100 column4" data-column="column4">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=3');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['location']; ?>
									<?php
									}
									
								?>
								</td>
								<td class="column100 column5" data-column="column5">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=4');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['location']; ?>
									<?php
									}
									
								?>
								</td>
								<td class="column100 column6" data-column="column6">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=5');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['location']; ?>
									<?php
									}
									
								?>
								</td>
							</tr>

							<tr class="row100">
								<td class="column100 column1" data-column="column1">Facilities</td>
								<td class="column100 column2" data-column="column2">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=1');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['facilities']; ?>
									<?php
									}
									
								?>
								</td>
								<td class="column100 column3" data-column="column3">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=2');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['facilities']; ?>
									<?php
									}
									
								?>
								</td>
								<td class="column100 column4" data-column="column4">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=3');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['facilities']; ?>
									<?php
									}
									
								?>
								</td>
								<td class="column100 column5" data-column="column5">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=4');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['facilities']; ?>
									<?php
									}
									
								?>
								</td>
								<td class="column100 column6" data-column="column6">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=5');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['facilities']; ?>
									<?php
									}
									
								?>
								</td>
							</tr>

							<tr class="row100">
								<td class="column100 column1" data-column="column1">Campuses</td>
								<td class="column100 column2" data-column="column2">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=1');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['campus']; ?>
									<?php
									}
									
								?>
								</td>
								<td class="column100 column3" data-column="column3">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=2');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['campus']; ?>
									<?php
									}
									
								?>
								</td>
								<td class="column100 column4" data-column="column4">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=3');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['campus']; ?>
									<?php
									}
									
								?>
								</td>
								<td class="column100 column5" data-column="column5">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=4');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['campus']; ?>
									<?php
									}
									
								?>
								</td>
								<td class="column100 column6" data-column="column6">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=5');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['campus']; ?>
									<?php
									}
									
								?>
								</td>
							</tr>

							<tr class="row100">
								<td class="column100 column1" data-column="column1">Courses</td>
								<td class="column100 column2" data-column="column2">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=1');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['course']; ?>
									<?php
									}
									
								?>
								</td>
								<td class="column100 column3" data-column="column3">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=2');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['course']; ?>
									<?php
									}
									
								?>
								</td>
								<td class="column100 column4" data-column="column4">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=3');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['course']; ?>
									<?php
									}
									
								?>
								</td>
								<td class="column100 column5" data-column="column5">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=4');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['course']; ?>
									<?php
									}
									
								?>
								</td>
								<td class="column100 column6" data-column="column6">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=5');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['course']; ?>
									<?php
									}
									
								?>
								</td>
							</tr>

							<tr class="row100">
								<td class="column100 column1" data-column="column1">Collaboration Partners</td>
								<td class="column100 column2" data-column="column2">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=1');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['collab']; ?>
									<?php
									}
									
								?>
								</td>
								<td class="column100 column3" data-column="column3">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=2');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['collab']; ?>
									<?php
									}
									
								?>
								</td>
								<td class="column100 column4" data-column="column4">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=3');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['collab']; ?>
									<?php
									}
									
								?>
								</td>
								<td class="column100 column5" data-column="column5">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=4');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['collab']; ?>
									<?php
									}
									
								?>
								</td>
								<td class="column100 column6" data-column="column6">
								<?php
									$connection = mysqli_connect('localhost', 'root', '', 'collegeinfo'); // Establishing Connection with Server
									$db = mysqli_select_db($connection, "collegeinfo"); // Selecting Database
									$query1 = mysqli_query($connection, 'SELECT * from information where entry_id=5');
									while ($row1 = mysqli_fetch_array($query1)) {
									?>
									<?php echo $row1['collab']; ?>
									<?php
									}
									
								?>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

			</div>
		</div>
	</div>


	

<!--===============================================================================================-->	
	<script src="compare/Table_Highlight_Vertical_Horizontal/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="compare/Table_Highlight_Vertical_Horizontal/vendor/bootstrap/js/popper.js"></script>
	<script src="compare/Table_Highlight_Vertical_Horizontal/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="compare/Table_Highlight_Vertical_Horizontal/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="compare/Table_Highlight_Vertical_Horizontal/js/main.js"></script>

</body>
</html>